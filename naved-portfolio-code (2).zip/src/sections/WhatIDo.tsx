import Reveal from "../components/Reveal";

const SERVICES = [
  {
    num: "01",
    title: "FRONTEND",
    desc: "Fast, accessible interfaces built with React and TypeScript.",
    img: "/img/service-branding.png",
  },
  {
    num: "02",
    title: "BACKEND",
    desc: "Clean APIs and reliable services with Node.js and Python.",
    img: "/img/service-webdesign.png",
  },
  {
    num: "03",
    title: "FULL-STACK APPS",
    desc: "End-to-end products, from database to polished user interface.",
    img: "/img/service-uiux.png",
  },
  {
    num: "04",
    title: "PROBLEM SOLVING",
    desc: "Turning messy requirements into simple, maintainable software.",
    img: "/img/service-artdirection.png",
  },
];

export default function WhatIDo() {
  return (
    <section className="bg-(--color-paper) py-14 text-(--color-ink-on-paper)">
      <div className="mx-auto max-w-6xl px-6">
        <Reveal className="mb-8 flex flex-wrap items-start justify-between gap-6">
          <div className="flex items-baseline gap-4">
            <span className="text-2xl text-(--color-canvas-2)">+</span>
            <h2 className="font-display text-4xl font-extrabold sm:text-5xl">
              WHAT I BUILD
            </h2>
          </div>
          <p className="max-w-[220px] text-sm leading-[1.7] text-(--color-canvas-2)">
            I build dependable software that is simple to use and easy to maintain.
          </p>
        </Reveal>

        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((s, i) => (
            <Reveal key={s.num} delay={i * 0.1}>
              <div className="group relative aspect-[3/3.6] overflow-hidden rounded p-5">
                <img
                  src={s.img}
                  alt={s.title}
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background:
                      "linear-gradient(180deg, rgba(28,5,7,0.15) 0%, rgba(28,5,7,0.95) 78%)",
                  }}
                />
                <span className="font-display absolute right-4 top-4 z-10 text-xs text-(--color-accent)">
                  {s.num}
                </span>
                <div className="absolute inset-x-5 bottom-5 z-10">
                  <h3 className="font-display text-lg tracking-wide text-(--color-ink)">
                    {s.title}
                  </h3>
                  <p className="mt-2 max-w-[170px] text-xs leading-[1.6] text-(--color-ink-dim)">
                    {s.desc}
                  </p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

const LINKS = [
  ["Home", "#/"],
  ["Skills", "#/skills"],
  ["Work", "#/work"],
  ["Process", "#/process"],
  ["Contact", "#/contact"],
];

export default function Header({ route }: { route: string }) {
  return (
    <header className="relative z-10 pt-6">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-6">
        <a href="#/" className="font-display text-lg tracking-wide">
          Naved Haque
        </a>
        <nav className="flex flex-wrap gap-x-6 gap-y-2">
          {LINKS.map(([label, href]) => {
            const active = "#" + route === href;
            return (
              <a
                key={href}
                href={href}
                aria-current={active ? "page" : undefined}
                className={`text-[11px] uppercase tracking-[0.22em] transition-colors hover:text-(--color-accent) focus-visible:ring-2 focus-visible:ring-(--color-accent) ${active ? "text-(--color-accent)" : "text-(--color-ink-dim)"}`}
              >
                {label}
              </a>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
